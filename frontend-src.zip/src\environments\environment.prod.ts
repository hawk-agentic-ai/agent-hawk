export const environment = {
  production: true,
  // Use a relative path so the frontend always calls the same host over HTTPS
  // nginx proxies /api to the FastAPI backend (port 8004)
  unifiedBackendUrl: '/api', // HTTPS production backend (via nginx proxy)
  supabaseUrl: '', // Removed for security - handled by backend
  supabaseAnonKey: '', // Removed for security - handled by backend
  difyApiKey: '', // Removed for security - handled by backend
  
  // Performance optimization settings
  unifiedBackend: {
    enabled: true,
    streamingEnabled: true,
    smartTemplateDetected: true,
    cacheEnabled: true
  }
};
