import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface Position {
  id: string;
  entityType: string;
  entityName: string;
  navType: string;
  functionalCurrency: string;
  originalValue: number;
  hedgedAmount: number;
  unhedgedAmount: number;
  lastUpdated: string;
  riskLevel: string;
  hedgeRatio: number;
}

@Injectable({
  providedIn: 'root'
})
export class PositionsService {
  private mockPositions: Position[] = [
    {
      id: '1',
      entityType: 'Subsidiary',
      entityName: 'MBS Bank Ltd Singapore',
      navType: 'Trading',
      functionalCurrency: 'SGD',
      originalValue: 125000000,
      hedgedAmount: 95000000,
      unhedgedAmount: 30000000,
      lastUpdated: '2024-12-09T10:30:00Z',
      riskLevel: 'Low',
      hedgeRatio: 76.0
    },
    {
      id: '2',
      entityType: 'Subsidiary',
      entityName: 'MBS Bank Hong Kong',
      navType: 'Investment',
      functionalCurrency: 'HKD',
      originalValue: 89000000,
      hedgedAmount: 67000000,
      unhedgedAmount: 22000000,
      lastUpdated: '2024-12-09T09:15:00Z',
      riskLevel: 'Medium',
      hedgeRatio: 75.3
    },
    {
      id: '3',
      entityType: 'Branch',
      entityName: 'MBS Bank London',
      navType: 'Trading',
      functionalCurrency: 'GBP',
      originalValue: 156000000,
      hedgedAmount: 140400000,
      unhedgedAmount: 15600000,
      lastUpdated: '2024-12-09T08:45:00Z',
      riskLevel: 'Low',
      hedgeRatio: 90.0
    },
    {
      id: '4',
      entityType: 'Branch',
      entityName: 'MBS Bank Tokyo',
      navType: 'Investment',
      functionalCurrency: 'JPY',
      originalValue: 234000000,
      hedgedAmount: 187200000,
      unhedgedAmount: 46800000,
      lastUpdated: '2024-12-09T07:20:00Z',
      riskLevel: 'Medium',
      hedgeRatio: 80.0
    },
    {
      id: '5',
      entityType: 'Subsidiary',
      entityName: 'MBS Bank India',
      navType: 'Trading',
      functionalCurrency: 'INR',
      originalValue: 78000000,
      hedgedAmount: 54600000,
      unhedgedAmount: 23400000,
      lastUpdated: '2024-12-09T11:10:00Z',
      riskLevel: 'High',
      hedgeRatio: 70.0
    },
    {
      id: '6',
      entityType: 'Branch',
      entityName: 'MBS Bank Sydney',
      navType: 'Investment',
      functionalCurrency: 'AUD',
      originalValue: 112000000,
      hedgedAmount: 89600000,
      unhedgedAmount: 22400000,
      lastUpdated: '2024-12-09T06:30:00Z',
      riskLevel: 'Low',
      hedgeRatio: 80.0
    },
    {
      id: '7',
      entityType: 'Subsidiary',
      entityName: 'MBS Bank Taiwan',
      navType: 'Trading',
      functionalCurrency: 'TWD',
      originalValue: 67000000,
      hedgedAmount: 46900000,
      unhedgedAmount: 20100000,
      lastUpdated: '2024-12-09T09:45:00Z',
      riskLevel: 'Medium',
      hedgeRatio: 70.0
    },
    {
      id: '8',
      entityType: 'Branch',
      entityName: 'MBS Bank New York',
      navType: 'Investment',
      functionalCurrency: 'USD',
      originalValue: 198000000,
      hedgedAmount: 178200000,
      unhedgedAmount: 19800000,
      lastUpdated: '2024-12-09T12:00:00Z',
      riskLevel: 'Low',
      hedgeRatio: 90.0
    },
    {
      id: '9',
      entityType: 'Subsidiary',
      entityName: 'MBS Bank Thailand',
      navType: 'Trading',
      functionalCurrency: 'THB',
      originalValue: 145000000,
      hedgedAmount: 101500000,
      unhedgedAmount: 43500000,
      lastUpdated: '2024-12-09T08:15:00Z',
      riskLevel: 'High',
      hedgeRatio: 70.0
    },
    {
      id: '10',
      entityType: 'Branch',
      entityName: 'MBS Bank Seoul',
      navType: 'Investment',
      functionalCurrency: 'KRW',
      originalValue: 89500000,
      hedgedAmount: 71600000,
      unhedgedAmount: 17900000,
      lastUpdated: '2024-12-09T10:45:00Z',
      riskLevel: 'Medium',
      hedgeRatio: 80.0
    }
  ];

  constructor() { }

  getPositions(): Observable<Position[]> {
    // Simulate API call with delay
    return of(this.mockPositions).pipe(delay(500));
  }

  getPositionById(id: string): Observable<Position | undefined> {
    const position = this.mockPositions.find(p => p.id === id);
    return of(position).pipe(delay(300));
  }

  getPositionsByEntityType(entityType: string): Observable<Position[]> {
    const filteredPositions = this.mockPositions.filter(p => p.entityType === entityType);
    return of(filteredPositions).pipe(delay(400));
  }

  getPositionsByCurrency(currency: string): Observable<Position[]> {
    const filteredPositions = this.mockPositions.filter(p => p.functionalCurrency === currency);
    return of(filteredPositions).pipe(delay(400));
  }

  getPositionsByRiskLevel(riskLevel: string): Observable<Position[]> {
    const filteredPositions = this.mockPositions.filter(p => p.riskLevel === riskLevel);
    return of(filteredPositions).pipe(delay(400));
  }

  getTotalHedgedAmount(): Observable<number> {
    const total = this.mockPositions.reduce((sum, position) => sum + position.hedgedAmount, 0);
    return of(total).pipe(delay(200));
  }

  getTotalUnhedgedAmount(): Observable<number> {
    const total = this.mockPositions.reduce((sum, position) => sum + position.unhedgedAmount, 0);
    return of(total).pipe(delay(200));
  }

  getAverageHedgeRatio(): Observable<number> {
    const average = this.mockPositions.reduce((sum, position) => sum + position.hedgeRatio, 0) / this.mockPositions.length;
    return of(Math.round(average * 10) / 10).pipe(delay(200));
  }

  updatePosition(position: Position): Observable<Position> {
    const index = this.mockPositions.findIndex(p => p.id === position.id);
    if (index !== -1) {
      this.mockPositions[index] = { ...position, lastUpdated: new Date().toISOString() };
      return of(this.mockPositions[index]).pipe(delay(300));
    }
    throw new Error('Position not found');
  }

  createPosition(position: Omit<Position, 'id' | 'lastUpdated'>): Observable<Position> {
    const newPosition: Position = {
      ...position,
      id: (this.mockPositions.length + 1).toString(),
      lastUpdated: new Date().toISOString()
    };
    this.mockPositions.push(newPosition);
    return of(newPosition).pipe(delay(400));
  }

  deletePosition(id: string): Observable<boolean> {
    const index = this.mockPositions.findIndex(p => p.id === id);
    if (index !== -1) {
      this.mockPositions.splice(index, 1);
      return of(true).pipe(delay(300));
    }
    return of(false).pipe(delay(300));
  }
}